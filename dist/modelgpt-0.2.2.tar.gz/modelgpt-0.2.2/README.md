# ModelGPT

**LLM-powered AutoML.** Describe your dataset, pick a task — ModelGPT asks an LLM to design, tune, and fit the best model for you. Works with OpenAI, Anthropic, Groq, Ollama, and any other LiteLLM-supported provider.

```python
from modelgpt import ModelGPT

mg = ModelGPT(model="gpt-4o-mini", api_key="sk-...")
model = mg.fit(X_train, y_train, task="regression")
predictions = model.predict(X_test)
```

---

## How it works

```
Your data  ──▶  Dataset summary  ──▶  LLM prompt
                                          │
                                          ▼
                                 LLM generates Python
                                 (ensemble + CV tuning)
                                          │
                                          ▼
                                   Sandboxed execution
                            (subprocess isolation, timeout=120s,
                            crash & resource containment)
                                          │
                             ┌────────────┴────────────┐
                             ▼                         ▼
                       Fitted model           Error? retry (→ LLM
                       returned               sees error, self-corrects)
                                                       │
                                              Max retries hit?
                                                       ▼
                                              Safe fallback model
```

ModelGPT feeds the LLM a structured dataset summary (shape, dtypes, missing values, target statistics, class distribution). The LLM returns raw Python that uses cross-validated hyperparameter search and an ensemble method. That code runs in a controlled namespace with `X` and `y` already bound. If it fails, the error is sent back to the LLM for self-correction — up to `max_retries` times. If every retry fails, ModelGPT falls back to a safe, well-tuned `GradientBoosting` model so `.fit()` never crashes your pipeline.

---

## Installation

Install the base package plus whichever backend you want to use:

```bash
pip install modelgpt[openai]      # OpenAI (gpt-4o, gpt-4o-mini, …)
pip install modelgpt[anthropic]   # Anthropic (claude-haiku-4-5, claude-opus-4-5, …)
pip install modelgpt[groq]        # Groq (fast + free tier)
pip install modelgpt[ollama]      # Ollama (local, no API key needed)
pip install modelgpt[all]         # everything including xgboost, lightgbm, catboost
```

---

## Quickstart

### OpenAI
```python
from modelgpt import ModelGPT

mg = ModelGPT(model="gpt-4o-mini", api_key="sk-...")
model = mg.fit(X_train, y_train, task="regression", metric="RMSE")
predictions = model.predict(X_test)
```

### Anthropic
```python
mg = ModelGPT(model="claude-haiku-4-5", api_key="sk-ant-...")
model = mg.fit(X_train, y_train, task="classification", metric="AUC")
```

### Groq
```python
mg = ModelGPT(model="groq/llama3-70b-8192", api_key="gsk_...")
model = mg.fit(X_train, y_train, task="classification")
```

### Ollama (local, no API key)
```bash
# First: install Ollama (https://ollama.com/download), then:
ollama pull qwen2.5-coder:7b
ollama serve
```
```python
mg = ModelGPT(model="ollama/qwen2.5-coder:7b")
model = mg.fit(X_train, y_train, task="regression")
```

### Using environment variables instead of passing `api_key`
```bash
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-ant-..."
export GROQ_API_KEY="gsk_..."
```
```python
mg = ModelGPT(model="gpt-4o-mini")   # picks up key from env automatically
```

---

## API Reference

### `ModelGPT(model, api_key, max_retries, verbose)`

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `model` | `str` | `"gpt-4o-mini"` | Any LiteLLM model string (see examples above) |
| `api_key` | `str \| None` | `None` | API key for the backend. If `None`, reads from environment variable |
| `max_retries` | `int` | `3` | How many times to retry + self-correct on code execution failure |
| `verbose` | `bool` | `True` | Print generated code and progress to stdout |

### `.fit(X, y, task, metric)`

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `X` | `pd.DataFrame` | — | Feature matrix |
| `y` | `pd.Series` | — | Target vector |
| `task` | `str` | `"regression"` | `"regression"` or `"classification"` |
| `metric` | `str \| None` | `None` | Metric hint passed to the LLM (e.g. `"RMSE"`, `"AUC"`, `"F1"`) |

Returns a fitted sklearn-compatible model with a `.predict()` method.

---

## Choosing a model

Larger and more capable models tend to generate better, more reliable code. Here are some good options ranked by capability:

| Provider | Model string | Notes |
|----------|-------------|-------|
| OpenAI | `"gpt-4o"` | Best results |
| OpenAI | `"gpt-4o-mini"` | Fast, cheap, good default |
| Anthropic | `"claude-opus-4-5"` | Excellent code generation |
| Anthropic | `"claude-haiku-4-5"` | Fast and affordable |
| Groq | `"groq/llama3-70b-8192"` | Very fast, free tier available |
| Ollama | `"ollama/qwen2.5-coder:7b"` | Local, fully private |
| Ollama | `"ollama/qwen2.5-coder:32b"` | Local, best quality |

---

## Tips for better results

**Tell the LLM which metric matters.** The `metric` argument is forwarded directly into the prompt:

```python
model = mg.fit(X_train, y_train, task="regression", metric="RMSE")
model = mg.fit(X_train, y_train, task="classification", metric="AUC")
```

**Increase retries for hard tasks.** If the LLM frequently generates broken code, raise `max_retries`:

```python
mg = ModelGPT(model="gpt-4o-mini", max_retries=5)
```

**Inspect what was generated.** With `verbose=True` (the default) the full generated code is printed. You can copy it, tweak it, and re-run it manually.

**Fallback is always safe.** If every retry fails, ModelGPT automatically falls back to a well-tuned `GradientBoostingRegressor` / `GradientBoostingClassifier`, so `.fit()` never crashes your pipeline.

**Install the boosting extras** for the best LLM-generated models:

```bash
pip install modelgpt[boosting]   # adds xgboost, lightgbm, catboost
```

---

## Project structure

```
modelGPT/
├── modelgpt/
│   ├── __init__.py          # Public API
│   └── modelgpt.py          # Core ModelGPT class
├── tests/                   # Test suite
├── example/
│   └── example_usage.py     # Quickstart demo (diabetes dataset)
├── pyproject.toml
└── README.md
```

---

## Requirements

- Python ≥ 3.10
- `litellm`, `pandas`, `scikit-learn`, `numpy` (installed automatically)
- An API key for your chosen backend **or** Ollama running locally

---

## License

MIT